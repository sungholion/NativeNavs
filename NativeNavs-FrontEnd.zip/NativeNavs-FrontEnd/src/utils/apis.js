export const API_Tour_Create = "http://i11d110.p.ssafy.io:8081/api/tours";
