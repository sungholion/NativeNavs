export const categoryItem = [
  { name: "시장", state: false, idx: 0 },
  { name: "액티비티", state: false, idx: 1 },
  { name: "자연", state: false, idx: 2 },
  { name: "역사", state: false, idx: 3 },
  { name: "문화", state: false, idx: 4 },
  { name: "축제", state: false, idx: 5 },
  { name: "음식", state: false, idx: 6 },
  { name: "트렌디", state: false, idx: 7 },
  { name: "랜드마크", state: false, idx: 8 },
  { name: "쇼핑", state: false, idx: 9 },
  { name: "미용", state: false, idx: 10 },
  { name: "사진", state: false, idx: 11 },
];
