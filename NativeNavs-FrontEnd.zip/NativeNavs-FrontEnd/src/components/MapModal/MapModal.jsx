import React from "react";

const PlanModal = () => {
  return <div>PlanModal</div>;
};

export default PlanModal;
