import TourEditorHead from "@/components/TourEditor/TourEditorHead";

const TourEdit = () => {
  return <div>TourEditor</div>;
};

export default TourEdit;
