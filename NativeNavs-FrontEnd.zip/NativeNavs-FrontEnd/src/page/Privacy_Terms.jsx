import React from "react";

const Privacy_Terms = () => {
  return <div>Privacy_Terms</div>;
};

export default Privacy_Terms;
