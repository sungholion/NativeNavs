import React from "react";
import { Router, Route, Outlet } from "react-router-dom";

const Tour = () => {
  return (
    <div>
      <Outlet />
    </div>
  );
};

export default Tour;
