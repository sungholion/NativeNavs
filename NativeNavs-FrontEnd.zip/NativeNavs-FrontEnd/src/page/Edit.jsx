import React from "react";
import { Outlet } from "react-router-dom";

const Edit = () => {
  return <div>수정</div>;
};

export default Edit;
