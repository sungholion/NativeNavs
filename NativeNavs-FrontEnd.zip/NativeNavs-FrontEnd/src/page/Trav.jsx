import React from "react";
import { Outlet } from "react-router-dom";

const Trav = () => {
  return (
    <div>
      Trav
      <Outlet />
    </div>
  );
};

export default Trav;
